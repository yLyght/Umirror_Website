import React from "react"

function Erro(){
    return(
        <div>
            <h1>404 PAGE NOT FOUND</h1>
        </div>
    )
}

export default Erro