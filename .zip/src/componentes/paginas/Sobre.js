import React from "react"

function Sobre(){
    return(
        <div>
            <h1>Sobre o Projeto</h1>
        </div>
    )
}

export default Sobre