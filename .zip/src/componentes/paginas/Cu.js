import React from "react"

function Cu(){
    return(
        <div>
            <h1>Sobre o Cu</h1>
        </div>
    )
}

export default Cu